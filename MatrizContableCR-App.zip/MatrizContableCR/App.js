import React, { useState, useRef } from 'react';
import {
  StyleSheet,
  View,
  ActivityIndicator,
  StatusBar,
  BackHandler,
  Platform,
  Alert,
} from 'react-native';
import { WebView } from 'react-native-webview';
import { Asset } from 'expo-asset';
import * as FileSystem from 'expo-file-system';

// Archivos web que se empaquetan con la app
const WEB_FILES = [
  { module: require('./assets/web/index.html'),      name: 'index.html'            },
  { module: require('./assets/web/wc-modulos-v14.5.js'), name: 'wc-modulos-v14.5.js' },
  { module: require('./assets/web/wc-formulas-patch.js'), name: 'wc-formulas-patch.js' },
  { module: require('./assets/web/wc-fndata.json'),  name: 'wc-fndata.json'        },
  { module: require('./assets/web/wc-translations.json'), name: 'wc-translations.json' },
];

const WEB_DIR = FileSystem.documentDirectory + 'web/';

export default function App() {
  const [ready, setReady] = useState(false);
  const [indexUri, setIndexUri] = useState(null);
  const webviewRef = useRef(null);
  const canGoBack = useRef(false);

  // Copiar archivos web al sistema de archivos local al iniciar
  React.useEffect(() => {
    (async () => {
      try {
        // Crear directorio web si no existe
        const dirInfo = await FileSystem.getInfoAsync(WEB_DIR);
        if (!dirInfo.exists) {
          await FileSystem.makeDirectoryAsync(WEB_DIR, { intermediates: true });
        }

        // Descargar y copiar cada archivo
        for (const file of WEB_FILES) {
          const asset = Asset.fromModule(file.module);
          await asset.downloadAsync();
          const dest = WEB_DIR + file.name;
          const destInfo = await FileSystem.getInfoAsync(dest);
          if (!destInfo.exists) {
            await FileSystem.copyAsync({ from: asset.localUri, to: dest });
          }
        }

        setIndexUri(WEB_DIR + 'index.html');
        setReady(true);
      } catch (e) {
        console.error('Error cargando archivos web:', e);
        Alert.alert('Error', 'No se pudieron cargar los archivos de la app.');
      }
    })();
  }, []);

  // Manejar botón atrás en Android
  React.useEffect(() => {
    if (Platform.OS !== 'android') return;
    const handler = BackHandler.addEventListener('hardwareBackPress', () => {
      if (canGoBack.current && webviewRef.current) {
        webviewRef.current.goBack();
        return true;
      }
      return false;
    });
    return () => handler.remove();
  }, []);

  if (!ready) {
    return (
      <View style={styles.loading}>
        <StatusBar backgroundColor="#2d7a0c" barStyle="light-content" />
        <ActivityIndicator size="large" color="#5abf2a" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#1e5208" barStyle="light-content" />
      <WebView
        ref={webviewRef}
        source={{ uri: indexUri }}
        style={styles.webview}
        originWhitelist={['*']}
        allowFileAccess={true}
        allowUniversalAccessFromFileURLs={true}
        allowFileAccessFromFileURLs={true}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={true}
        renderLoading={() => (
          <View style={styles.loading}>
            <ActivityIndicator size="large" color="#5abf2a" />
          </View>
        )}
        onNavigationStateChange={(state) => {
          canGoBack.current = state.canGoBack;
        }}
        onError={(e) => {
          console.error('WebView error:', e.nativeEvent);
        }}
        mixedContentMode="always"
        cacheEnabled={true}
        pullToRefreshEnabled={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2d7a0c',
  },
  webview: {
    flex: 1,
  },
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2d7a0c',
  },
});
