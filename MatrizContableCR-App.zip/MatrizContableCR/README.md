# Matriz Contable CR — App Móvil
> Desarrollado por **KCN Studio** · kenychinchilla.com

App Android & iOS generada con Expo + React Native WebView.

---

## 🚀 Pasos para generar el APK/IPA

### 1. Subir este proyecto a GitHub
Crea un repo nuevo en GitHub y sube todos estos archivos.

### 2. Instalar dependencias (en tu PC con Node.js)
```bash
npm install
```

### 3. Instalar EAS CLI
```bash
npm install -g eas-cli
eas login
```

### 4. Configurar el proyecto en Expo
```bash
eas init
```
Esto reemplaza automáticamente el `projectId` en `app.json`.

### 5. Generar APK de prueba (Android)
```bash
eas build --platform android --profile preview
```
Te genera un `.apk` descargable directo desde expo.dev.

### 6. Generar para producción (Google Play / App Store)
```bash
# Android (.aab para Google Play)
eas build --platform android --profile production

# iOS (.ipa para App Store)
eas build --platform ios --profile production
```

---

## 📁 Estructura
```
MatrizContableCR/
├── App.js                    ← Componente principal con WebView
├── app.json                  ← Configuración de la app
├── eas.json                  ← Configuración de builds
├── package.json
└── assets/
    ├── web/
    │   ├── index.html        ← App web completa
    │   ├── wc-modulos-v14.5.js
    │   ├── wc-formulas-patch.js
    │   ├── wc-fndata.json
    │   └── wc-translations.json
    ├── icon.png              ← Ícono 1024x1024
    ├── splash.png            ← Splash screen
    └── adaptive-icon.png     ← Ícono adaptivo Android
```

---

## ⚠️ Íconos requeridos
Antes de hacer el build necesitás agregar:
- `assets/icon.png` — 1024×1024px
- `assets/splash.png` — 1284×2778px (fondo verde #2d7a0c)
- `assets/adaptive-icon.png` — 1024×1024px

---

## 📞 Soporte
KCN Studio · +506 8735-9034 · kchinchilla.pos@gmail.com
